﻿Imports System.Data.Odbc
Public Class CustomerCrystalBill
    Dim cn As New OdbcConnection("dsn=student;user=root;pwd=root")
    Dim cmd As New OdbcCommand

    Private Sub CustomerCrystalBill_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        showbillno()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            cn.Open()
            Dim da As New OdbcDataAdapter("select distinct(Bill_no),Medicine_id,Customer_id,T_bill_amount,C_P_mode,Bill_date from payment where Bill_no=' " & ComboBox1.Text & " '", cn)
            Dim ds As New DataSet
            da.Fill(ds)
            Dim rpath = "C:\Users\WASIM\Documents\Visual Studio 2008\Projects\pms\PMS\PMS\CrystalReportCBill.rpt"
            Dim doc As New CrystalDecisions.CrystalReports.Engine.ReportDocument
            doc.Load(rpath)
            doc.SetDataSource(ds.Tables(0))
            CrystalReportViewer1.ReportSource = doc
            CrystalReportViewer1.RefreshReport()
            cn.Close()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub
    Sub showbillno()
        cn.Open()
        Try
            cmd = New OdbcCommand("select distinct(Bill_no) from payment", cn)
            Dim dr As OdbcDataReader = cmd.ExecuteReader
            ComboBox1.Items.Clear()
            While (dr.Read())
                ComboBox1.Items.Add(dr(0))
            End While
            dr.Close()
            cn.Close()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub
End Class