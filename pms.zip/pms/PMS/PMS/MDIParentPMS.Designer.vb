﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MDIParentPMS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MDIParentPMS))
        Me.MenuStrip = New System.Windows.Forms.MenuStrip
        Me.WELCOMEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.WeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MAINFORMSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MedicinevbToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MedicinevbToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.OTHERFORMSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OrderinfovbToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SupplierPaymentvbToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BillvbToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BILLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SupplierCrystalBillvbToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerCrystalBillvbToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EXTRAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerPaymentInfovbToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EXITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStrip = New System.Windows.Forms.ToolStrip
        Me.NewToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.OpenToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.SaveToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.PrintToolStripButton = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.StatusStrip = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.MenuStrip.SuspendLayout()
        Me.ToolStrip.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip
        '
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WELCOMEToolStripMenuItem, Me.MAINFORMSToolStripMenuItem, Me.OTHERFORMSToolStripMenuItem, Me.BILLToolStripMenuItem, Me.EXTRAToolStripMenuItem, Me.EXITToolStripMenuItem})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(842, 24)
        Me.MenuStrip.TabIndex = 5
        Me.MenuStrip.Text = "MenuStrip"
        '
        'WELCOMEToolStripMenuItem
        '
        Me.WELCOMEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WeToolStripMenuItem})
        Me.WELCOMEToolStripMenuItem.Name = "WELCOMEToolStripMenuItem"
        Me.WELCOMEToolStripMenuItem.Size = New System.Drawing.Size(76, 20)
        Me.WELCOMEToolStripMenuItem.Text = "WELCOME"
        '
        'WeToolStripMenuItem
        '
        Me.WeToolStripMenuItem.Name = "WeToolStripMenuItem"
        Me.WeToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.WeToolStripMenuItem.Text = "WelcomePage.vb"
        '
        'MAINFORMSToolStripMenuItem
        '
        Me.MAINFORMSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MedicinevbToolStripMenuItem, Me.MedicinevbToolStripMenuItem1})
        Me.MAINFORMSToolStripMenuItem.Name = "MAINFORMSToolStripMenuItem"
        Me.MAINFORMSToolStripMenuItem.Size = New System.Drawing.Size(92, 20)
        Me.MAINFORMSToolStripMenuItem.Text = "MAIN FORMS"
        '
        'MedicinevbToolStripMenuItem
        '
        Me.MedicinevbToolStripMenuItem.Name = "MedicinevbToolStripMenuItem"
        Me.MedicinevbToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.MedicinevbToolStripMenuItem.Text = "Supplier.vb"
        '
        'MedicinevbToolStripMenuItem1
        '
        Me.MedicinevbToolStripMenuItem1.Name = "MedicinevbToolStripMenuItem1"
        Me.MedicinevbToolStripMenuItem1.Size = New System.Drawing.Size(139, 22)
        Me.MedicinevbToolStripMenuItem1.Text = "Medicine.vb"
        '
        'OTHERFORMSToolStripMenuItem
        '
        Me.OTHERFORMSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OrderinfovbToolStripMenuItem, Me.SupplierPaymentvbToolStripMenuItem, Me.BillvbToolStripMenuItem})
        Me.OTHERFORMSToolStripMenuItem.Name = "OTHERFORMSToolStripMenuItem"
        Me.OTHERFORMSToolStripMenuItem.Size = New System.Drawing.Size(97, 20)
        Me.OTHERFORMSToolStripMenuItem.Text = "OTHER FORMS"
        '
        'OrderinfovbToolStripMenuItem
        '
        Me.OrderinfovbToolStripMenuItem.Name = "OrderinfovbToolStripMenuItem"
        Me.OrderinfovbToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.OrderinfovbToolStripMenuItem.Text = "Order_Info.vb"
        '
        'SupplierPaymentvbToolStripMenuItem
        '
        Me.SupplierPaymentvbToolStripMenuItem.Name = "SupplierPaymentvbToolStripMenuItem"
        Me.SupplierPaymentvbToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.SupplierPaymentvbToolStripMenuItem.Text = "Supplier_Payment.vb"
        '
        'BillvbToolStripMenuItem
        '
        Me.BillvbToolStripMenuItem.Name = "BillvbToolStripMenuItem"
        Me.BillvbToolStripMenuItem.Size = New System.Drawing.Size(185, 22)
        Me.BillvbToolStripMenuItem.Text = "Bill.vb"
        '
        'BILLToolStripMenuItem
        '
        Me.BILLToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SupplierCrystalBillvbToolStripMenuItem, Me.CustomerCrystalBillvbToolStripMenuItem})
        Me.BILLToolStripMenuItem.Name = "BILLToolStripMenuItem"
        Me.BILLToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.BILLToolStripMenuItem.Text = "BILL"
        '
        'SupplierCrystalBillvbToolStripMenuItem
        '
        Me.SupplierCrystalBillvbToolStripMenuItem.Name = "SupplierCrystalBillvbToolStripMenuItem"
        Me.SupplierCrystalBillvbToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.SupplierCrystalBillvbToolStripMenuItem.Text = "SupplierCrystalBill.vb"
        '
        'CustomerCrystalBillvbToolStripMenuItem
        '
        Me.CustomerCrystalBillvbToolStripMenuItem.Name = "CustomerCrystalBillvbToolStripMenuItem"
        Me.CustomerCrystalBillvbToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.CustomerCrystalBillvbToolStripMenuItem.Text = "CustomerCrystalBill.vb"
        '
        'EXTRAToolStripMenuItem
        '
        Me.EXTRAToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomerPaymentInfovbToolStripMenuItem})
        Me.EXTRAToolStripMenuItem.Name = "EXTRAToolStripMenuItem"
        Me.EXTRAToolStripMenuItem.Size = New System.Drawing.Size(53, 20)
        Me.EXTRAToolStripMenuItem.Text = "EXTRA"
        '
        'CustomerPaymentInfovbToolStripMenuItem
        '
        Me.CustomerPaymentInfovbToolStripMenuItem.Name = "CustomerPaymentInfovbToolStripMenuItem"
        Me.CustomerPaymentInfovbToolStripMenuItem.Size = New System.Drawing.Size(220, 22)
        Me.CustomerPaymentInfovbToolStripMenuItem.Text = "Customer_Payment_Info.vb"
        '
        'EXITToolStripMenuItem
        '
        Me.EXITToolStripMenuItem.Name = "EXITToolStripMenuItem"
        Me.EXITToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.EXITToolStripMenuItem.Text = "EXIT"
        '
        'ToolStrip
        '
        Me.ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripButton, Me.OpenToolStripButton, Me.SaveToolStripButton, Me.ToolStripSeparator1, Me.PrintToolStripButton, Me.ToolStripSeparator2})
        Me.ToolStrip.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip.Name = "ToolStrip"
        Me.ToolStrip.Size = New System.Drawing.Size(842, 25)
        Me.ToolStrip.TabIndex = 6
        Me.ToolStrip.Text = "ToolStrip"
        '
        'NewToolStripButton
        '
        Me.NewToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.NewToolStripButton.Image = CType(resources.GetObject("NewToolStripButton.Image"), System.Drawing.Image)
        Me.NewToolStripButton.ImageTransparentColor = System.Drawing.Color.Black
        Me.NewToolStripButton.Name = "NewToolStripButton"
        Me.NewToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.NewToolStripButton.Text = "New"
        '
        'OpenToolStripButton
        '
        Me.OpenToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.OpenToolStripButton.Image = CType(resources.GetObject("OpenToolStripButton.Image"), System.Drawing.Image)
        Me.OpenToolStripButton.ImageTransparentColor = System.Drawing.Color.Black
        Me.OpenToolStripButton.Name = "OpenToolStripButton"
        Me.OpenToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.OpenToolStripButton.Text = "Open"
        '
        'SaveToolStripButton
        '
        Me.SaveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SaveToolStripButton.Image = CType(resources.GetObject("SaveToolStripButton.Image"), System.Drawing.Image)
        Me.SaveToolStripButton.ImageTransparentColor = System.Drawing.Color.Black
        Me.SaveToolStripButton.Name = "SaveToolStripButton"
        Me.SaveToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.SaveToolStripButton.Text = "Save"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'PrintToolStripButton
        '
        Me.PrintToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PrintToolStripButton.Image = CType(resources.GetObject("PrintToolStripButton.Image"), System.Drawing.Image)
        Me.PrintToolStripButton.ImageTransparentColor = System.Drawing.Color.Black
        Me.PrintToolStripButton.Name = "PrintToolStripButton"
        Me.PrintToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.PrintToolStripButton.Text = "Print"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 431)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(842, 22)
        Me.StatusStrip.TabIndex = 7
        Me.StatusStrip.Text = "StatusStrip"
        '
        'ToolStripStatusLabel
        '
        Me.ToolStripStatusLabel.Name = "ToolStripStatusLabel"
        Me.ToolStripStatusLabel.Size = New System.Drawing.Size(39, 17)
        Me.ToolStripStatusLabel.Text = "Status"
        '
        'MDIParentPMS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.BackgroundImage = Global.PMS.My.Resources.Resources.freestocks_nss2eRzQwgw_unsplash
        Me.ClientSize = New System.Drawing.Size(842, 453)
        Me.Controls.Add(Me.ToolStrip)
        Me.Controls.Add(Me.MenuStrip)
        Me.Controls.Add(Me.StatusStrip)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip
        Me.Name = "MDIParentPMS"
        Me.Text = "MDIParentPMS"
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.ToolStrip.ResumeLayout(False)
        Me.ToolStrip.PerformLayout()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents ToolStripStatusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents NewToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents OpenToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents SaveToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents WELCOMEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MAINFORMSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MedicinevbToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MedicinevbToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OTHERFORMSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrderinfovbToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierPaymentvbToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BillvbToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BILLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SupplierCrystalBillvbToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerCrystalBillvbToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXTRAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerPaymentInfovbToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintToolStripButton As System.Windows.Forms.ToolStripButton

End Class
