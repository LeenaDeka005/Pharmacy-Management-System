﻿Imports System.Data.Odbc
Public Class Customer_Payment_Info
    Dim cn As New OdbcConnection
    Dim cmd As New OdbcCommand

    Private Sub Customer_Payment_Info_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        showdb()
        additem()
    End Sub
    Sub showdb()
        Dim cn As OdbcConnection
        Dim da As New OdbcDataAdapter
        Dim dt As New DataTable
        'Dim x As Integer
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        da = New OdbcDataAdapter("select * from payment", cn)
        da.Fill(dt)
        DGV1.DataSource = dt
        cn.Close()
    End Sub
    Sub additem()
        ComboBox1.Items.Add("Cash")
        ComboBox1.Items.Add("Cheque")
        ComboBox1.Items.Add("Google pay")
        ComboBox1.Items.Add("Paytm")
        ComboBox1.Items.Add("Debit Card")
        ComboBox1.Items.Add("Credit Card")
    End Sub
    Sub clear()
        TextBox1.Clear()
        ComboBox1.Text = ""
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
        TextBox1.Focus()

    End Sub

    Private Sub Btn_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Exit.Click
        Me.Close()
    End Sub

    

    Private Sub Btn_Search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Search.Click
        'Btn_Save.Enabled = False
        'Btn_Update.Enabled = False
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox6.Enabled = False
        ComboBox1.Enabled = False
        DTP1.Enabled = False
        Dim cn As OdbcConnection
        Dim da As New OdbcDataAdapter
        Dim dt As New DataTable
        Dim x As Integer
        Dim y As Integer
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        Try
            x = InputBox("ENTER THE BILL NO TO BE SEARCHED")
            y = InputBox("ENTER THE MEDICINE ID TO BE SEARCHED")
            da = New OdbcDataAdapter("select * from payment where Bill_no=' " & x & " ' and Medicine_id=' " & y & " ' ", cn)
            da.Fill(dt)
            TextBox1.Text = dt.Rows(0).Item(0)
            TextBox2.Text = dt.Rows(0).Item(1)
            TextBox3.Text = dt.Rows(0).Item(2)
            TextBox4.Text = dt.Rows(0).Item(3)
            TextBox5.Text = dt.Rows(0).Item(4)
            TextBox6.Text = dt.Rows(0).Item(5)
            ComboBox1.Text = dt.Rows(0).Item(6)
            DTP1.Value = dt.Rows(0).Item(7)
            DGV1.DataSource = dt
            cn.Close()
        Catch ex As Exception
            MsgBox("INVALID BILL NO", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub Btn_Update_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Update.Click
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox6.Enabled = False
        ComboBox1.Enabled = False
        DTP1.Enabled = False

        Dim cn As OdbcConnection
        Dim cmd As OdbcCommand
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        Try
            If TextBox1.Text <> "" And ComboBox1.Text <> "" And TextBox2.Text <> "" And TextBox3.Text <> "" And TextBox4.Text <> "" And TextBox5.Text <> "" And TextBox6.Text <> "" Then
                cmd = New OdbcCommand("update payment set Bill_no=' " & TextBox1.Text & " ', Medicine_id=' " & TextBox2.Text & " ', Customer_id=' " & TextBox3.Text & " ', Customer_name=' " & TextBox4.Text & " ', Customer_address=' " & TextBox5.Text & " ', T_bill_amount=' " & TextBox6.Text & " ', C_P_mode=' " & ComboBox1.Text & " ', Bill_date=' " & Format(DTP1.Value, "yyyy-MM-dd") & " ' where Bill_no=' " & TextBox1.Text & " '", cn)
                cmd.ExecuteNonQuery()
                MsgBox("RECORD UPDATED SUCCESSFULLY", MsgBoxStyle.OkOnly)
            Else
                MsgBox("ERROR!", MsgBoxStyle.Exclamation)
            End If
            cn.Close()
            clear()
            showdb()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    
End Class