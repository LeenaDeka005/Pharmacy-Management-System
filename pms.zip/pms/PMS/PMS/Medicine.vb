﻿Imports System.Data.Odbc
Public Class Medicine
    Dim cn As OdbcConnection
    Dim cmd As OdbcCommand
    Private Sub Medicine_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        additem()
        FKey()
        showdb()
    End Sub
    Sub additem()
        ComboBox2.Items.Add("Syrup")
        ComboBox2.Items.Add("Tablet")
        ComboBox2.Items.Add("Capsule")
        ComboBox2.Items.Add("Ointment")
        ComboBox2.Items.Add("Drop")
        ComboBox2.Items.Add("Spray")
        ComboBox2.Items.Add("Antibiotic")
        ComboBox2.Items.Add("Antihistamine")
        ComboBox2.Items.Add("Antacid")
        ComboBox2.Items.Add("Decongestant")
    End Sub
    Sub FKey()
        Dim cn As OdbcConnection
        Dim cmd As OdbcCommand
        ComboBox1.Items.Clear()
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        cmd = New OdbcCommand("select * from supplier", cn)
        Dim dr As OdbcDataReader = cmd.ExecuteReader
        While dr.Read
            ComboBox1.Items.Add(dr(0))
        End While
        dr.Close()
        cn.Close()
    End Sub
    Sub showdb()
        Dim cn As OdbcConnection
        Dim da As New OdbcDataAdapter
        Dim dt As New DataTable
        'Dim x As Integer
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        da = New OdbcDataAdapter("select * from medicine", cn)
        da.Fill(dt)
        DGV1.DataSource = dt
        cn.Close()
    End Sub
    Sub clear()
        TextBox1.Clear()
        ComboBox1.Text = ""
        TextBox2.Clear()
        TextBox3.Clear()
        ComboBox2.Text = ""
        TextBox4.Clear()
        TextBox1.Focus()
    End Sub

    Private Sub save_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles save_btn.Click
        Dim cn As OdbcConnection
        Dim cmd As OdbcCommand
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        Try
            If TextBox1.Text <> "" And ComboBox1.Text <> "" And TextBox2.Text <> "" And TextBox3.Text <> "" And ComboBox2.Text <> "" And TextBox4.Text <> "" Then
                cmd = New OdbcCommand("insert into medicine values(' " & TextBox1.Text & " ', ' " & ComboBox1.Text & " ', ' " & TextBox2.Text & " ', ' " & TextBox3.Text & " ', ' " & ComboBox2.Text & " ', ' " & TextBox4.Text & " ', ' " & Format(DTP1.Value, "yyyy-MM-dd") & " ', ' " & Format(DTP2.Value, "yyyy-MM-dd") & " ')", cn)
                cmd.ExecuteNonQuery()
                MsgBox("RECORD SAVED SUCCESSFULLY", MsgBoxStyle.OkOnly)
            Else
                MsgBox("ERROR", MsgBoxStyle.Exclamation)
            End If
            cn.Close()
            clear()
            showdb()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub search_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles search_btn.Click
        'save_btn.Enabled = False
        Dim cn As OdbcConnection
        Dim da As New OdbcDataAdapter
        Dim dt As New DataTable
        Dim x As Integer
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        Try
            x = InputBox("ENTER THE  MEDICINE ID TO BE SEARCHED")
            da = New OdbcDataAdapter("select * from medicine where Medicine_id=' " & x & " ' ", cn)
            da.Fill(dt)
            TextBox1.Text = dt.Rows(0).Item(0)
            ComboBox1.Text = dt.Rows(0).Item(1)
            TextBox2.Text = dt.Rows(0).Item(2)
            TextBox3.Text = dt.Rows(0).Item(3)
            ComboBox2.Text = dt.Rows(0).Item(4)
            TextBox4.Text = dt.Rows(0).Item(5)
            DTP1.Value = dt.Rows(0).Item(6)
            DTP2.Value = dt.Rows(0).Item(7)
            DGV1.DataSource = dt
            cn.Close()
        Catch ex As Exception
            MsgBox("INVALID MEDICINE ID", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub update_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles update_btn.Click
        Dim cn As OdbcConnection
        Dim cmd As OdbcCommand
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        Try
            If TextBox1.Text <> "" And ComboBox1.Text <> "" And TextBox2.Text <> "" And TextBox3.Text <> "" And ComboBox2.Text <> "" And TextBox4.Text <> "" Then
                cmd = New OdbcCommand("update medicine set Supplier_id=' " & Trim(ComboBox1.Text) & " ', Medicine_name=' " & Trim(TextBox2.Text) & " ', Medicine_qnty=' " & Trim(TextBox3.Text) & " ', Medicine_type=' " & Trim(ComboBox2.Text) & " ', Medicine_price=' " & Trim(TextBox4.Text) & " ', Mf_date=' " & Format(DTP1.Value, "yyyy-MM-dd") & " ', Exp_date=' " & Format(DTP2.Value, "yyyy-MM-dd") & " ' where Medicine_id=' " & Trim(TextBox1.Text) & " '", cn)
                cmd.ExecuteNonQuery()
                MsgBox("RECORD UPDATED SUCCESSFULLY", MsgBoxStyle.OkOnly)
            Else
                MsgBox("ERROR!", MsgBoxStyle.Exclamation)
            End If
            cn.Close()
            clear()
            showdb()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub delete_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles delete_btn.Click
        Dim cn As OdbcConnection
        Dim cmd As OdbcCommand
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        Try
            If TextBox1.Text <> "" And ComboBox1.Text <> "" And TextBox2.Text <> "" And TextBox3.Text <> "" And ComboBox2.Text <> "" And TextBox4.Text <> "" Then
                cmd = New OdbcCommand("delete from medicine where Medicine_id=' " & TextBox1.Text & " '", cn)
                cmd.ExecuteNonQuery()
                MsgBox("DELETED SUCCESSFULLY")
            Else
                MsgBox("DELETE UNSUCCESSFULL", MsgBoxStyle.Information)
            End If
            cn.Close()
            clear()
            showdb()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub exit_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exit_btn.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Order_Info.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Bill.Show()
    End Sub
End Class