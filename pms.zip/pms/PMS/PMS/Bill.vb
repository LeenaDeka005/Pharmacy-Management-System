﻿Imports System.Data.Odbc
Public Class Bill
    Dim cn As New OdbcConnection("dsn=student;user=root;pwd=root")
    Dim cmd As New OdbcCommand

    Private Sub Bill_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        fk()
        com()
        clear()
        showdb()
    End Sub
    Sub fk()
        cn.Open()
        cmd = New OdbcCommand("select * from medicine", cn)
        Dim dr As OdbcDataReader = cmd.ExecuteReader
        ComboBox1.Items.Clear()
        While (dr.Read)
            ComboBox1.Items.Add(dr(0))
        End While
        dr.Close()
        cn.Close()
    End Sub
    Sub com()
        ComboBox2.Items.Add("CASH")
        ComboBox2.Items.Add("CHEQUE")
        ComboBox2.Items.Add("GOOGLE PAY")
        ComboBox2.Items.Add("PAYTM")
        ComboBox2.Items.Add("DEBIT CARD")
        ComboBox2.Items.Add("CREDIT CARD")
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim cn As New OdbcConnection("dsn=student;user=root;pwd=root")
        Dim cmd As New OdbcCommand
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        cn.Open()
        cmd = New OdbcCommand("select * from medicine where Medicine_id=' " & ComboBox1.Text & " '", cn)
        Dim dr As OdbcDataReader = cmd.ExecuteReader
        While (dr.Read)
            TextBox2.Text = dr(2).ToString
            TextBox3.Text = dr(5).ToString
        End While
        dr.Close()
        cn.Close()
    End Sub
    Sub clear()
        TextBox1.Focus()
    End Sub

    Private Sub Btn_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Add.Click
        Dim cmd1 As New OdbcCommand
        Dim x As Integer
        Try
            TextBox8.Text = Val(TextBox3.Text) * Val(TextBox4.Text)
            cn.Open()
            x = 0
            cmd1 = New OdbcCommand("insert into payment(Bill_no,Medicine_id) values(' " & TextBox1.Text & " ',' " & ComboBox1.Text & " ')", cn)
            cmd1.ExecuteNonQuery()
            cmd = New OdbcCommand("insert into cus_bill values(' " & TextBox1.Text & " ',' " & ComboBox1.Text & " ',' " & TextBox5.Text & " ',' " & TextBox2.Text & " ',' " & TextBox3.Text & " ',' " & TextBox4.Text & " ',' " & TextBox8.Text & " ')", cn)
            cmd.ExecuteNonQuery()
            x = 1
            MsgBox("Record Added Successfully")
            If x = 1 Then
                cmd = New OdbcCommand("update medicine set Medicine_qnty = Medicine_qnty - ' " & TextBox4.Text & " ' where Medicine_id=' " & ComboBox1.Text & " '", cn)
                cmd.ExecuteNonQuery()
            End If
            cn.Close()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub Btn_Cal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cal.Click
        Try
            cn.Open()
            cmd = New OdbcCommand("select sum(M_t_amount) from cus_bill where Bill_no=' " & TextBox1.Text & " '", cn)
            Dim dr As OdbcDataReader = cmd.ExecuteReader
            While (dr.Read())
                TextBox9.Text = dr(0).ToString
            End While
            dr.Close()
            cn.Close()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            cn.Open()
            cmd = New OdbcCommand("update payment set Bill_no=' " & Trim(TextBox1.Text) & " ', Customer_id=' " & Trim(TextBox5.Text) & " ', Customer_name=' " & Trim(TextBox6.Text) & " ', Customer_address=' " & Trim(TextBox7.Text) & " ', T_Bill_amount=' " & Trim(TextBox9.Text) & " ', C_P_mode=' " & Trim(ComboBox2.Text) & " ', Bill_date=' " & Format(DTP1.Value, "yyyy-MM-dd") & " ' where Bill_no=' " & Trim(TextBox1.Text) & " '", cn)
            cmd.ExecuteNonQuery()
            MsgBox("Record Saved Successfully")
            cn.Close()
            showdb()
            ComboBox1.Text = ""
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox8.Clear()
            TextBox1.Focus()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub Btn_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Exit.Click
        Me.Close()
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
        Dim q As Integer
        Try
            cn.Open()
            cmd = New OdbcCommand("select * from medicine where Medicine_id=' " & ComboBox1.Text & " '", cn)
            Dim dr As OdbcDataReader = cmd.ExecuteReader
            While (dr.Read())
                q = dr(3)
            End While
            If Val(TextBox4.Text) <= q Then
                Label13.Text = "QUANTITY AVAILABLE"
            Else
                Label13.Text = "QUANTITY UNAVAILABLE"
            End If
            dr.Close()
            cn.Close()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub
    Sub showdb()
        Dim cn As OdbcConnection
        Dim da As New OdbcDataAdapter
        Dim dt As New DataTable
        'Dim x As Integer
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        da = New OdbcDataAdapter("select * from payment", cn)
        da.Fill(dt)
        DGV1.DataSource = dt
        cn.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Customer_Payment_Info.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        CustomerCrystalBill.Show()
    End Sub
End Class