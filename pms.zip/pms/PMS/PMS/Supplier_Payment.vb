﻿Imports System.Data.Odbc
Public Class Supplier_Payment
    Dim cn As OdbcConnection
    Dim cmd As OdbcCommand
    Private Sub Supplier_Payment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        additem()
        FKey()
        showdb()
    End Sub
    Sub additem()
        ComboBox2.Items.Add("Cash")
        ComboBox2.Items.Add("Cheque")
        ComboBox2.Items.Add("G-pay")
        ComboBox2.Items.Add("Paytm")
    End Sub
    Sub FKey()
        Dim cn As OdbcConnection
        Dim cmd As OdbcCommand
        ComboBox1.Items.Clear()
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        cmd = New OdbcCommand("select distinct(O_no) from order1", cn)
        Dim dr As OdbcDataReader = cmd.ExecuteReader
        While dr.Read
            ComboBox1.Items.Add(dr(0))
        End While
        dr.Close()
        cn.Close()
    End Sub
    Sub showdb()
        Dim cn As OdbcConnection
        Dim da As New OdbcDataAdapter
        Dim dt As New DataTable
        'Dim x As Integer
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        da = New OdbcDataAdapter("select * from s_payment", cn)
        da.Fill(dt)
        DGV1.DataSource = dt
        cn.Close()
    End Sub

    Private Sub exit_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exit_btn.Click
        Me.Close()
    End Sub

    Private Sub save_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles save_btn.Click
        Dim cn As OdbcConnection
        Dim cmd As OdbcCommand
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        Try
            If TextBox1.Text <> "" And TextBox3.Text <> "" And ComboBox1.Text <> "" And TextBox2.Text <> "" And ComboBox2.Text <> "" Then
                cmd = New OdbcCommand("insert into s_payment values(' " & TextBox1.Text & " ', ' " & ComboBox1.Text & " ', ' " & TextBox3.Text & " ', ' " & TextBox2.Text & " ', ' " & Format(DTP1.Value, "yyyy-MM-dd") & " ', ' " & ComboBox2.Text & " ')", cn)
                cmd.ExecuteNonQuery()
                MsgBox("RECORD SAVED SUCCESSFULLY", MsgBoxStyle.OkOnly)
            Else
                MsgBox("ERROR", MsgBoxStyle.Exclamation)
            End If
            cn.Close()
            clear()
            showdb()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub
    Sub clear()
        TextBox1.Clear()
        TextBox3.Clear()
        ComboBox1.Text = ""
        TextBox2.Clear()
        ComboBox2.Text = ""
        TextBox1.Focus()
    End Sub

    Private Sub search_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles search_btn.Click
        'save_btn.Enabled = False
        Dim cn As OdbcConnection
        Dim da As New OdbcDataAdapter
        Dim dt As New DataTable
        Dim x As Integer
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        Try
            x = InputBox("ENTER THE  PAYMENT NO. TO BE SEARCHED")
            da = New OdbcDataAdapter("select * from s_payment where pid=' " & x & " ' ", cn)
            da.Fill(dt)
            TextBox1.Text = dt.Rows(0).Item(0)
            TextBox3.Text = dt.Rows(0).Item(2)
            ComboBox1.Text = dt.Rows(0).Item(1)
            TextBox2.Text = dt.Rows(0).Item(3)
            DTP1.Value = dt.Rows(0).Item(4)
            ComboBox2.Text = dt.Rows(0).Item(5)
            DGV1.DataSource = dt
            cn.Close()
        Catch ex As Exception
            MsgBox("INVALID PAYMENT NO", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub update_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles update_btn.Click
        Dim cn As OdbcConnection
        Dim cmd As OdbcCommand
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        Try
            If TextBox1.Text <> "" And ComboBox1.Text <> "" And TextBox3.Text <> "" And TextBox2.Text <> "" And ComboBox2.Text <> "" Then
                cmd = New OdbcCommand("update s_payment set O_no=' " & Trim(ComboBox1.Text) & " ', Supplier_id=' " & Trim(TextBox3.Text) & " ', p_amount=' " & Trim(TextBox2.Text) & " ', p_date=' " & Format(DTP1.Value, "yyyy-MM-dd") & " ', p_mode=' " & Trim(ComboBox2.Text) & " ' where pid =' " & Trim(TextBox1.Text) & " '", cn)
                cmd.ExecuteNonQuery()
                MsgBox("RECORD UPDATED SUCCESSFULLY", MsgBoxStyle.OkOnly)
            Else
                MsgBox("ERROR!", MsgBoxStyle.Exclamation)
            End If
            cn.Close()
            clear()
            showdb()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub delete_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles delete_btn.Click
        Dim cn As OdbcConnection
        Dim cmd As OdbcCommand
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        Try
            If TextBox1.Text <> "" And ComboBox1.Text <> "" And TextBox2.Text <> "" And ComboBox2.Text <> "" Then
                cmd = New OdbcCommand("delete from s_payment where pid=' " & TextBox1.Text & " '", cn)
                cmd.ExecuteNonQuery()
                MsgBox("DELETED SUCCESSFULLY")
            Else
                MsgBox("DELETE UNSUCCESSFULL", MsgBoxStyle.Information)
            End If
            cn.Close()
            clear()
            showdb()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim cn As New OdbcConnection("dsn=student;user=root;pwd=root")
        Dim cmd As New OdbcCommand
        Try
            TextBox2.Enabled = False
            TextBox3.Enabled = False
            cn.Open()
            cmd = New OdbcCommand("select * from order1 where O_no=' " & ComboBox1.Text & " '", cn)
            Dim dr As OdbcDataReader = cmd.ExecuteReader
            While (dr.Read())
                TextBox2.Text = dr(8).ToString
                TextBox3.Text = dr(2).ToString
            End While
            dr.Close()
            cn.Close()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        SupplierCrystalBill.Show()
    End Sub
End Class