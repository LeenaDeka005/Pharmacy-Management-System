﻿Imports System.Data.Odbc
Public Class Order_Info
    Dim cn As New OdbcConnection("dsn=student;user=root;pwd=root")
    Dim cmd As New OdbcCommand

    Private Sub Order_Info_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        fk()
        showdb()
    End Sub
    Sub fk()
        cn.Open()
        cmd = New OdbcCommand("select * from medicine", cn)
        Dim dr As OdbcDataReader = cmd.ExecuteReader
        ComboBox1.Items.Clear()
        While (dr.Read())
            ComboBox1.Items.Add(dr(0))
        End While
        dr.Close()
        cn.Close()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim cn As New OdbcConnection("dsn=student;user=root;pwd=root")
        Dim cmd As New OdbcCommand
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        cn.Open()
        cmd = New OdbcCommand("select * from medicine where Medicine_id=' " & ComboBox1.Text & " '", cn)
        Dim dr As OdbcDataReader = cmd.ExecuteReader
        While (dr.Read())
            TextBox2.Text = dr(2).ToString
            TextBox3.Text = dr(5).ToString
            TextBox5.Text = dr(1).ToString
        End While
        dr.Close()
        cn.Close()
    End Sub
    Sub showdb()
        Dim cn As OdbcConnection
        Dim da As New OdbcDataAdapter
        Dim dt As New DataTable
        'Dim x As Integer
        cn = New OdbcConnection("dsn=student;user=root;pwd=root")
        cn.Open()
        da = New OdbcDataAdapter("select * from order1", cn)
        da.Fill(dt)
        DGV1.DataSource = dt
        cn.Close()
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cmd1 As New OdbcCommand
        'Dim x As Integer
        Try
            TextBox6.Text = Val(TextBox3.Text) * Val(TextBox4.Text)
            cn.Open()
            'x = 0
            cmd1 = New OdbcCommand("insert into order1(O_no,Medicine_id) values(' " & TextBox1.Text & " ', ' " & ComboBox1.Text & " ')", cn)
            cmd1.ExecuteNonQuery()
            cmd = New OdbcCommand("insert into orderinfo values(' " & TextBox1.Text & " ', ' " & ComboBox1.Text & " ', ' " & TextBox2.Text & " ', ' " & TextBox3.Text & " ', ' " & TextBox4.Text & " ', ' " & TextBox6.Text & " ')", cn)
            cmd.ExecuteNonQuery()
            'x = 1
            MsgBox("record added sucessfully")
            'If x = 1 Then
            '    cmd = New OdbcCommand("update medicine set Medicine_qnty=Medicine_qnty + ' " & TextBox4.Text & " ' where Medicine_id=' " & ComboBox1.Text & " '", cn)
            '    cmd.ExecuteNonQuery()
            'End If
            cn.Close()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            cn.Open()
            cmd = New OdbcCommand("select sum(t_price) from orderinfo where O_no=' " & TextBox1.Text & " '", cn)
            Dim dr As OdbcDataReader = cmd.ExecuteReader
            While (dr.Read())
                TextBox7.Text = dr(0).ToString
            End While
            dr.Close()
            cn.Close()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim cmd1 As New OdbcCommand
        Dim cmd2 As New OdbcCommand
        cn.Open()
        Try
            cmd = New OdbcCommand("update order1 set O_no=' " & Trim(TextBox1.Text) & " ', Supplier_id=' " & Trim(TextBox5.Text) & " ', Order_date=' " & Format(DTP1.Value, "yyyy-MM-dd") & " ', i_name=' " & Trim(TextBox2.Text) & " ', i_price=' " & Trim(TextBox3.Text) & " ', qnty=' " & Trim(TextBox4.Text) & " ', t_price=' " & Trim(TextBox6.Text) & " ' where O_no=' " & Trim(TextBox1.Text) & " ' and Medicine_id=' " & Trim(ComboBox1.Text) & " '", cn)
            cmd.ExecuteNonQuery()
            cmd1 = New OdbcCommand("update order1 set t_o_amount=' " & Trim(TextBox7.Text) & " ' where O_no=' " & Trim(TextBox1.Text) & " ' ", cn)
            cmd1.ExecuteNonQuery()
            cmd2 = New OdbcCommand("update medicine set Supplier_id=' " & Trim(TextBox5.Text) & " ' where Medicine_id=' " & Trim(ComboBox1.Text) & " '", cn)
            cmd2.ExecuteNonQuery()
            MsgBox("record saved")
            cn.Close()
            showdb()
            ComboBox1.Text = ""
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            'TextBox5.Clear()
            TextBox6.Clear()
        Catch ex As Exception
            MsgBox("SOMETHING IS WRONG!", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Supplier_Payment.Show()
    End Sub
End Class